<?php
    interface IParte4{
        public function Eliminar();
    }
<?php
    interface IParte3{
        public function Modificar();
    }